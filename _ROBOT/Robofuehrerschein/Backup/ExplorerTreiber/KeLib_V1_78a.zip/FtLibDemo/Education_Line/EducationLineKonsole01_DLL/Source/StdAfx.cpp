// stdafx.cpp : Quelltextdatei, die nur die Standard-Includes einbindet
//	EducationLineKonsole01.pch ist die vorkompilierte Header-Datei
//	stdafx.obj enth�lt die vorkompilierte Typinformation

#include "stdafx.h"

// ZU ERLEDIGEN: Verweis auf alle zus�tzlichen Header-Dateien, die Sie in STDAFX.H
// und nicht in dieser Datei ben�tigen
